# 🛡️ AdBlock Guard

**Block ads, trackers, and pop-ups. Faster, cleaner, private browsing.**

A lightweight, free Chrome extension that blocks ads and trackers using Chrome's modern Manifest V3 engine — fast, private, and fully under your control.

---

## ✨ Features

- **Blocks display ads** — banners, pop-ups, and interstitials
- **Skips YouTube video ads** — automatically, in the player
- **Stops trackers** — analytics and tracking scripts blocked
- **Faster pages** — less to download, less data used
- **Per-site control** — allow ads on sites you want to support
- **Live counter** — see ads blocked per page and in total
- **100% free** — no account, no sign-up, no data collection

---

## 🚀 Install

### From Chrome Web Store
*(link coming soon)*

### Manually (developer mode)
1. Download or clone this repo
2. Open `chrome://extensions`
3. Enable **Developer mode** (top-right)
4. Click **Load unpacked**
5. Select the `adblock-guard` folder
6. Pin the shield icon to your toolbar

---

## 🎛️ How to use

1. Click the shield icon to open the popup
2. Use the top toggle to turn protection on/off globally
3. Use **This site** toggle to disable blocking on the current site only
4. Watch the blocked-ads counter grow as you browse

---

## 🧩 How it works

| Layer | Role |
|-------|------|
| **Network blocking** (`declarativeNetRequest`) | Stops ad/tracker requests before they download |
| **Cosmetic filtering** (CSS + JS) | Hides leftover empty ad boxes on all sites |
| **YouTube script** | Detects and skips video ads in the player |
| **Allowlist** (dynamic rules) | Disables blocking on sites you choose |

Everything runs locally. Nothing is sent to any server.

---

## 🔒 Privacy

AdBlock Guard collects **no** data. No tracking, no telemetry, no accounts.
See the full [Privacy Policy](PRIVACY.md).

---

## ⚠️ Notes

- AdBlock Guard is an independent project, **not affiliated with** Google, YouTube, or any ad network.
- YouTube ad handling depends on YouTube's current page structure and may need updates over time.
- The bundled blocklist is a starter set. Coverage can be expanded with community filter lists (e.g. EasyList).

---

## 📄 License

MIT

## 📬 Support

Issues and questions: **som.shrestha@themegrill.com**
