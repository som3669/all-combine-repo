const toggle = document.getElementById("toggle");
const tabCountEl = document.getElementById("tabCount");
const totalCountEl = document.getElementById("totalCount");
const statusEl = document.getElementById("status");
const siteHostEl = document.getElementById("siteHost");
const siteToggle = document.getElementById("siteToggle");
const siteRow = document.getElementById("siteRow");

let currentHost = null;

function render(state) {
  toggle.checked = state.enabled;
  tabCountEl.textContent = state.tabCount;
  totalCountEl.textContent = state.totalBlocked.toLocaleString();

  currentHost = state.host;
  if (state.host) {
    siteHostEl.textContent = state.host;
    siteToggle.checked = state.siteEnabled;
    siteRow.style.display = "flex";
  } else {
    siteRow.style.display = "none";
  }

  // Global off overrides per-site.
  siteToggle.disabled = !state.enabled;

  if (!state.enabled) {
    statusEl.textContent = "Protection paused";
    statusEl.classList.add("off");
  } else if (state.host && !state.siteEnabled) {
    statusEl.textContent = "Paused on this site";
    statusEl.classList.add("off");
  } else {
    statusEl.textContent = "Protection active";
    statusEl.classList.remove("off");
  }
}

async function refresh() {
  const state = await chrome.runtime.sendMessage({ type: "GET_STATE" });
  render(state);
}

toggle.addEventListener("change", async () => {
  await chrome.runtime.sendMessage({
    type: "SET_ENABLED",
    enabled: toggle.checked,
  });
  refresh();
});

siteToggle.addEventListener("change", async () => {
  if (!currentHost) return;
  await chrome.runtime.sendMessage({
    type: "TOGGLE_SITE",
    host: currentHost,
    enabled: siteToggle.checked, // true = block here, false = whitelist
  });
  refresh();
});

refresh();
