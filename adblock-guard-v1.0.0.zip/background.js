// AdBlock Guard - service worker
// Tracks blocked-request counts, drives the toolbar badge,
// and manages a per-site allowlist (whitelist).

const RULESET_ID = "ads";
const WHITELIST_RULE_BASE = 100000; // dynamic allow-rule id range

// Per-tab blocked counts for this session.
const tabCounts = {};

// ---------- helpers ----------

async function getWhitelist() {
  const { whitelist = [] } = await chrome.storage.local.get("whitelist");
  return whitelist;
}

function hostFromUrl(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

// Lifetime total, persisted in storage.
async function bumpTotal(n) {
  const { totalBlocked = 0 } = await chrome.storage.local.get("totalBlocked");
  await chrome.storage.local.set({ totalBlocked: totalBlocked + n });
}

// ---------- block counter + badge ----------
// Production-safe counting via getMatchedRulesInBrowserSession().
// (onRuleMatchedDebug only fires for unpacked/dev builds.)

// Timestamp of each tab's current navigation, so per-page counts
// exclude matches from earlier pages in the same tab.
const navStart = {};

// Running session total already folded into the lifetime counter,
// so the periodic poll only adds new matches.
let sessionSeen = 0;

const feedbackApi =
  chrome.declarativeNetRequest.getMatchedRulesInBrowserSession;

async function countForTab(tabId) {
  if (!feedbackApi) return 0;
  try {
    const res = await chrome.declarativeNetRequest.getMatchedRulesInBrowserSession(
      { tabId, minTimeStamp: navStart[tabId] || 0 }
    );
    return res.rulesMatchedInfo.length;
  } catch {
    return 0;
  }
}

function setBadge(tabId, count) {
  chrome.action.setBadgeBackgroundColor({ color: "#e53935" });
  chrome.action.setBadgeText({
    tabId,
    text: count > 0 ? String(count) : "",
  });
}

async function refreshTabBadge(tabId) {
  const count = await countForTab(tabId);
  tabCounts[tabId] = count;
  setBadge(tabId, count);
}

// Poll the whole session and fold new matches into the lifetime total.
async function pollTotal() {
  if (!feedbackApi) return;
  try {
    const res =
      await chrome.declarativeNetRequest.getMatchedRulesInBrowserSession();
    const now = res.rulesMatchedInfo.length;
    const delta = now - sessionSeen;
    if (delta > 0) {
      sessionSeen = now;
      await bumpTotal(delta);
    } else if (now < sessionSeen) {
      // Session was reset (browser restart) - rebaseline.
      sessionSeen = now;
    }
  } catch {
    /* feedback API unavailable - skip */
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading" && changeInfo.url) {
    navStart[tabId] = Date.now();
    tabCounts[tabId] = 0;
    setBadge(tabId, 0);
  }
  if (changeInfo.status === "complete") {
    // Small delay so late requests are counted.
    setTimeout(() => refreshTabBadge(tabId), 800);
    pollTotal();
  }
});

chrome.tabs.onActivated.addListener(({ tabId }) => refreshTabBadge(tabId));

chrome.tabs.onRemoved.addListener((tabId) => {
  delete tabCounts[tabId];
  delete navStart[tabId];
});

// Periodic total poll (badge updates on nav; this keeps the total fresh).
chrome.alarms.create("pollTotal", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "pollTotal") pollTotal();
});

// ---------- global on/off ----------

async function setEnabled(enabled) {
  await chrome.storage.local.set({ enabled });
  if (enabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({
      enableRulesetIds: [RULESET_ID],
    });
  } else {
    await chrome.declarativeNetRequest.updateEnabledRulesets({
      disableRulesetIds: [RULESET_ID],
    });
  }
}

// ---------- per-site allowlist ----------
// For each whitelisted host we add a dynamic "allow" rule at priority 2.
// It outranks the priority-1 block rules, so nothing is blocked on that site.

async function syncWhitelistRules() {
  const whitelist = await getWhitelist();

  // Remove all previous dynamic allow rules in our range.
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeIds = existing
    .filter((r) => r.id >= WHITELIST_RULE_BASE)
    .map((r) => r.id);

  const addRules = whitelist.map((host, i) => ({
    id: WHITELIST_RULE_BASE + i,
    priority: 2,
    action: { type: "allow" },
    condition: {
      // Allow every request whose page (initiator) is this host.
      initiatorDomains: [host],
      resourceTypes: [
        "main_frame", "sub_frame", "script", "image",
        "xmlhttprequest", "stylesheet", "font", "media",
        "object", "ping", "other",
      ],
    },
  }));

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: removeIds,
    addRules,
  });
}

async function toggleSite(host, allow) {
  let whitelist = await getWhitelist();
  if (allow) {
    // allow=true means "keep blocking" -> remove from whitelist
    whitelist = whitelist.filter((h) => h !== host);
  } else {
    // allow=false means "disable on this site" -> add to whitelist
    if (!whitelist.includes(host)) whitelist.push(host);
  }
  await chrome.storage.local.set({ whitelist });
  await syncWhitelistRules();
}

// ---------- messaging ----------

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "SET_ENABLED") {
    setEnabled(msg.enabled).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "TOGGLE_SITE") {
    // msg.enabled = should blocking be ON for this site?
    toggleSite(msg.host, msg.enabled).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "GET_STATE") {
    (async () => {
      const { enabled = true, totalBlocked = 0 } =
        await chrome.storage.local.get(["enabled", "totalBlocked"]);
      const whitelist = await getWhitelist();
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      const host = tab ? hostFromUrl(tab.url) : null;
      // Poll total + live per-tab count for a fresh popup view.
      await pollTotal();
      const { totalBlocked: freshTotal = totalBlocked } =
        await chrome.storage.local.get("totalBlocked");
      const tabCount = tab ? await countForTab(tab.id) : 0;
      sendResponse({
        enabled,
        totalBlocked: freshTotal,
        tabCount,
        host,
        siteEnabled: host ? !whitelist.includes(host) : true,
      });
    })();
    return true;
  }
});

// ---------- lifecycle ----------

chrome.runtime.onInstalled.addListener(async () => {
  const { enabled } = await chrome.storage.local.get("enabled");
  if (enabled === undefined) await setEnabled(true);
  await syncWhitelistRules();
});

chrome.runtime.onStartup.addListener(syncWhitelistRules);
