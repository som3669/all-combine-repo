// AdBlock Guard - dynamic cosmetic cleanup for all sites.
// CSS handles static hiding; this catches lazy-injected ad frames
// and collapses empty leftover containers.

(function () {
  "use strict";

  const HOST = location.hostname.replace(/^www\./, "");
  let enabled = true;
  let siteAllowed = true;

  function readState() {
    chrome.storage.local.get(["enabled", "whitelist"], (r) => {
      if (r.enabled !== undefined) enabled = r.enabled;
      siteAllowed = !(r.whitelist || []).includes(HOST);
      // On whitelisted sites, drop the static hiding CSS class hook.
      document.documentElement.toggleAttribute(
        "data-abg-off",
        !(enabled && siteAllowed)
      );
    });
  }
  readState();
  chrome.storage.onChanged.addListener(readState);

  const AD_SRC = [
    "doubleclick.net",
    "googlesyndication.com",
    "googleadservices.com",
    "amazon-adsystem.com",
    "adnxs.com",
    "taboola.com",
    "outbrain.com",
    "/ads/",
    "/advert",
  ];

  function clean() {
    if (!enabled || !siteAllowed) return;
    // Kill iframes pointing at known ad sources.
    document.querySelectorAll("iframe[src]").forEach((f) => {
      const src = f.src || "";
      if (AD_SRC.some((s) => src.includes(s))) f.remove();
    });
  }

  const obs = new MutationObserver(clean);
  if (document.body) {
    obs.observe(document.documentElement, { childList: true, subtree: true });
    clean();
  }
})();
