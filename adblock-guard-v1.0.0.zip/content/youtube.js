// AdBlock Guard - YouTube video ad remover.
// Skips/seeks past video ads and strips ad DOM.
// NOTE: YouTube changes its player often; selectors may need updating.

(function () {
  "use strict";

  const HOST = location.hostname.replace(/^www\./, "");
  let enabled = true;
  let siteAllowed = true; // false = whitelisted, do nothing

  function readState() {
    chrome.storage.local.get(["enabled", "whitelist"], (r) => {
      if (r.enabled !== undefined) enabled = r.enabled;
      const wl = r.whitelist || [];
      siteAllowed = !wl.includes(HOST);
    });
  }
  readState();
  chrome.storage.onChanged.addListener(readState);

  function active() {
    return enabled && siteAllowed;
  }

  // DOM elements to hide/remove outright (banner, feed, masthead ads).
  const AD_SELECTORS = [
    "#player-ads",
    "#masthead-ad",
    "ytd-display-ad-renderer",
    "ytd-ad-slot-renderer",
    "ytd-in-feed-ad-layout-renderer",
    "ytd-banner-promo-renderer",
    "ytd-promoted-sparkles-web-renderer",
    "ytd-companion-slot-renderer",
    ".ytp-ad-overlay-slot",
    ".ytp-ad-overlay-container",
    ".ytp-featured-product",
    "#panels ytd-ads-engagement-panel-content-renderer",
  ];

  function stripAdDom() {
    for (const sel of AD_SELECTORS) {
      document.querySelectorAll(sel).forEach((el) => el.remove());
    }
  }

  // Core: skip playing video ads.
  function skipVideoAd() {
    const player = document.querySelector(".html5-video-player");
    if (!player) return;

    const isAd = player.classList.contains("ad-showing");
    if (!isAd) return;

    // 1. Click the skip button if present.
    const skipBtn = document.querySelector(
      ".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button"
    );
    if (skipBtn) {
      skipBtn.click();
      return;
    }

    // 2. No skip yet -> fast-forward the ad video to its end.
    const video = document.querySelector("video.html5-main-video");
    if (video && !isNaN(video.duration) && video.duration > 0) {
      video.currentTime = video.duration;
      video.muted = true; // silence during the jump
    }
  }

  function tick() {
    if (!active()) return;
    try {
      skipVideoAd();
      stripAdDom();
    } catch (e) {
      /* selector drift - ignore */
    }
  }

  // Poll fast enough to catch ad start, cheap enough to not lag.
  setInterval(tick, 300);

  // Also react to DOM mutations for snappier removal.
  const obs = new MutationObserver(() => tick());
  const start = () => {
    if (document.body) {
      obs.observe(document.body, { childList: true, subtree: true });
      tick();
    } else {
      requestAnimationFrame(start);
    }
  };
  start();
})();
